create trigger TIB_QUESTIONNAIRE
  before insert
  on QUESTIONNAIRE
  for each row
  declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
begin
    --  Column ""id"" uses sequence S_user_role
    select S_questionnaire.NEXTVAL INTO :new.id from dual;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
/


create trigger TIB_VOTERESULT
  before insert
  on VOTERESULT
  for each row
  DECLARE
    INTEGRITY_ERROR  EXCEPTION;
    ERRNO            INTEGER;
    ERRMSG           CHAR(200);
    DUMMY            INTEGER;
    FOUND            BOOLEAN;

BEGIN
    --  COLUMN ""ID"" USES SEQUENCE S_USER_ROLE
    select s_voteresult.nextval into :new.id from dual;

--  ERRORS HANDLING
EXCEPTION
    WHEN INTEGRITY_ERROR THEN
       RAISE_APPLICATION_ERROR(ERRNO, ERRMSG);
END;
/


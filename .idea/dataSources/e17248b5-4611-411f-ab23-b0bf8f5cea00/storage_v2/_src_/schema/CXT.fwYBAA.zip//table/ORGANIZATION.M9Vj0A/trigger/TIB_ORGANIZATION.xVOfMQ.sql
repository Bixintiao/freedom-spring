create trigger TIB_ORGANIZATION
  before insert
  on ORGANIZATION
  for each row
  DECLARE
    INTEGRITY_ERROR  EXCEPTION;
    ERRNO            INTEGER;
    ERRMSG           CHAR(200);
    DUMMY            INTEGER;
    FOUND            BOOLEAN;

BEGIN
    --  Column ""id"" uses sequence S_organization  将序列SEQ_TEST的下一个值 赋给新插入数据的id
    SELECT S_ORGANIZATION.NEXTVAL INTO :NEW.ID FROM DUAL;

--  Errors handling
EXCEPTION
    WHEN INTEGRITY_ERROR THEN
       RAISE_APPLICATION_ERROR(ERRNO, ERRMSG);
END;
/


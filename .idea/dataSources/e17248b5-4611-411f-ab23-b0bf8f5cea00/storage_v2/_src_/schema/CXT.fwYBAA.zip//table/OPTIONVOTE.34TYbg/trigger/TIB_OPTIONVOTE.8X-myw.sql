create trigger TIB_OPTIONVOTE
  before insert
  on OPTIONVOTE
  for each row
  DECLARE
    INTEGRITY_ERROR  EXCEPTION;
    ERRNO            INTEGER;
    ERRMSG           CHAR(200);
    DUMMY            INTEGER;
    FOUND            BOOLEAN;

BEGIN
    --  COLUMN ""ID"" USES SEQUENCE S_USER_ROLE
    select s_optionvote.nextval into :new.id from dual;

--  ERRORS HANDLING
EXCEPTION
    WHEN INTEGRITY_ERROR THEN
       RAISE_APPLICATION_ERROR(ERRNO, ERRMSG);
END;
/

